# Changelog

## 0.0.1 (2025-07-01)
- Initial release
